<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function pre_uninstall() {
   global $sugar_config, $sugar_version;

   // DESINSTALAMOS TODOS LOS HOOKS QUE EXISTAN
   if ($_REQUEST['mode'] == 'Uninstall') {   
      require_once('modules/DHA_PlantillasDocumentos/UI_Hooks.php');   
      MailMergeReports_after_ui_frame_hook_remove_all_modules();
   } 
   
   
   // BORRADO DEL DIRECTORIO DE PLANTILLAS DE DOCUMENTOS (solo en el caso de que se haya pedido borrar la tabla)
   $borrar_tablas = 'true';
   if(isset($_REQUEST['remove_tables'])){
      $borrar_tablas = $_REQUEST['remove_tables'];
   }
   
   if ($_REQUEST['mode'] == 'Uninstall' && $borrar_tablas == 'true') {

      $template_dir = trim($sugar_config['DHA_templates_dir']);
      if (!$template_dir) {
         $template_dir = 'document_templates/';   // default templates dir
      }
      
      $template_dir = getcwd() . "/". $template_dir; 
      if (is_dir($template_dir)) {
         @rmdir_recursive($template_dir);
      }   
   }
//}

?>