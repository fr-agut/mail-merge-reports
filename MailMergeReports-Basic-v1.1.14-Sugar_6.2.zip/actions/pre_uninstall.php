<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function pre_uninstall() {
   global $sugar_config, $sugar_version;

   // RESTAURAMOS LOS FICHEROS ORIGINALES DE SUGAR 
   if ($_REQUEST['mode'] == 'Uninstall') {
      require_once("modules/DHA_PlantillasDocumentos/sugar_files/{$sugar_version}/copydefs.php");
      foreach ($copydefs as $copydef) {
         $GLOBALS['log']->debug("*********************** MailMerge Reports: RESTORING {$copydef['to']}");
         
         $from = getcwd() . "/modules/DHA_PlantillasDocumentos/sugar_files/{$sugar_version}/original/" . $copydef['from'];
         $to = getcwd() . "/" . $copydef['to'];
         $OK = copy($from, $to);
         
         if ($OK)
            $GLOBALS['log']->debug("*********************** MailMerge Reports: RESTORED {$copydef['to']}");
         else 
            $GLOBALS['log']->debug("*********************** MailMerge Reports: Fail RESTORING {$copydef['to']}");   
      }
   }
   
   
   // BORRADO DEL DIRECTORIO DE PLANTILLAS DE DOCUMENTOS (solo en el caso de que se haya pedido borrar la tabla)
   $borrar_tablas = 'true';
   if(isset($_REQUEST['remove_tables'])){
      $borrar_tablas = $_REQUEST['remove_tables'];
   }
   
   if ($_REQUEST['mode'] == 'Uninstall' && $borrar_tablas == 'true') {
      $template_dir = getcwd() . "/". $sugar_config['DHA_templates_dir']; 
      if (is_dir($template_dir)) {
         @rmdir_recursive($template_dir);
      }     
   }
//}

?>