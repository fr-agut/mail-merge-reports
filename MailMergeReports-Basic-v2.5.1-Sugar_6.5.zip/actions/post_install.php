<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function post_install() {
   
   if ($_REQUEST['mode'] == 'Install') {
      global $sugar_config, $sugar_version, $current_language, $app_list_strings;
      require_once('modules/Configurator/Configurator.php');
      require_once('modules/DHA_PlantillasDocumentos/UI_Hooks.php');

      // ASIGNACION DEL IDIOMA POR DEFECTO DE LAS PLANTILLAS EN BASE AL IDIOMA DEL SISTEMA
      // En el pre_install se ha asignado ya al parametro DHA_templates_default_lang el valor por defecto 'en_US' (si no estaba ya asignado en el sistema) ... aqui se intenta refinar un poco mas esa asignaci�n
      
      // Nota: en este punto parece que Sugar no ha cargado las extensiones del lenguaje en $app_list_strings, asi que cargamos esa variable a traves del fichero de lenguaje del componente
      //require_once("custom/Extension/application/Ext/Language/{$current_language}.MailMergeReports.php");         
      require_once("custom/Extension/application/Ext/Language/en_us.MailMergeReports.php");          
      
      $configurator = new Configurator();
      $idioma = '';
      if (isset($configurator->config['DHA_templates_default_lang']))
         $idioma = $configurator->config['DHA_templates_default_lang'];  
      unset($configurator); 

      // Si ya se tenia el idioma definido previamente, y no es el idioma por defecto ('en_US' se asigna en el pre_install) y el idioma existe en la lista de idiomas, 
      // no intentaremos averiguar el idioma por defecto, usamos el que ya hab�a
      $buscar_idioma_defecto = true;
      if ($idioma && $idioma != 'en_US' && isset($app_list_strings['dha_plantillasdocumentos_idiomas_dom'][$idioma])) {
         $buscar_idioma_defecto = false;
      }
      
      if ($buscar_idioma_defecto) {
         if (isset($sugar_config['default_language']))
            $idioma_defecto = $sugar_config['default_language'];
         else 
            $idioma_defecto = $current_language;
            
         if ($idioma_defecto){
            $idioma = '';
            $idioma_defecto = strtolower($idioma_defecto);
            
            foreach ($app_list_strings['dha_plantillasdocumentos_idiomas_dom'] as $key => $value) {
               if (strtolower($key) == $idioma_defecto) {
                  $idioma = $key;
                  break;
               }
            }
            
            if (!$idioma && strpos($idioma_defecto, '_') !== false) {
               $idioma_defecto = explode('_', $idioma_defecto);
               $idioma_defecto = $idioma_defecto[0];
               
               foreach ($app_list_strings['dha_plantillasdocumentos_idiomas_dom'] as $key => $value) {
                  if (strtolower($key) == $idioma_defecto) {
                     $idioma = $key;
                     break;
                  }
               }         
            }
            
            if (!$idioma) {
               $idioma = 'en_US';
            }         
            
            if ($idioma) {
               $configurator = new Configurator();
               $configurator->config['DHA_templates_default_lang'] = $idioma;
               $configurator->handleOverride();
               unset($configurator);         
            }
         }
      }
      
      
   
      // INSTALAMOS EL HOOK DEL MODULO
      // Si ya hab�a una instalaci�n anterior, recogemos el hist�rico de los m�dulos habilitados y habilitaremos el hook s�lo en esos m�dulos, 
      // en caso contrario instalaremos el hook para todos los m�dulos por defecto
      $configurator = new Configurator();
      if (isset($configurator->config['DHA_templates_historical_enabled_modules'])) {
         foreach ($configurator->config['DHA_templates_historical_enabled_modules'] as $module_name => $install) {
            if ($install) {
               MailMergeReports_after_ui_frame_hook_module_install($module_name);
            }
         }
      }
      else {
         MailMergeReports_after_ui_frame_hook_install_all_modules();      
      }
      unset($configurator);
   }

//}

?>

