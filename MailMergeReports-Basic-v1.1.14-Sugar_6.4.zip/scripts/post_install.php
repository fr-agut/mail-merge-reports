﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function post_install() {
   
   if ($_REQUEST['mode'] == 'Install') {

      // INSTALACION DE LAS PLANTILLAS DE EJEMPLO 
      // nota: se crea este codigo como script y no como accion porque en la accion post_execute todavia no esta creada la tabla de plantillas en la base de datos
      
      global $current_user, $db;
            
      $file_example_defs = array (
         1 => array (
            'file' => 'Opportunities.docx',
            'extension' => 'docx',
            'name' => 'EXAMPLE - Opportunities (Basic)',
            'module' => 'Opportunities',
         ),
         2 => array (
            'file' => 'Opportunities.odt',
            'extension' => 'odt',
            'name' => 'EXAMPLE - Opportunities (Basic)',
            'module' => 'Opportunities',
         ), 
      ); 

      require_once('modules/Configurator/Configurator.php');
      $configurator = new Configurator();
      $IdiomaPlantilla = $configurator->config['DHA_templates_default_lang'];
      $templates_dir = getcwd() . "/". $configurator->config['DHA_templates_dir'];
      unset($configurator);
      
      $fecha_hora = gmdate('Y-m-d H:i:s');
      $fecha = gmdate('Y-m-d');
      
      // Si el directorio de plantillas ya existe es porque vamos a hacer una reinstalacion, y por lo tanto los ejemplos ya se habian copiado anteriormente
      if (!is_dir($templates_dir)) {
         foreach ($file_example_defs as $key => $file_example_def) {      
         
            // RECOGEMOS LAS VARIABLES NECESARIAS PARA CREAR UN REGISTRO DE PLANTILLA
            $id = create_guid(); //$key;
            $NombrePlantilla = $file_example_def['name'];
            $EstadoPlantilla = 'Draft'; //'BORRADOR';
            $ModuloPlantilla = $file_example_def['module'];
            $extension = $file_example_def['extension'];
            $filename = $file_example_def['file'];
            
            if ($extension == 'docx') 
               $file_mime_type = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            elseif ($extension == 'odt') 
               $file_mime_type = 'application/vnd.oasis.opendocument.text';            
            
            
            // GUARDAMOS EL REGISTRO DE LA PLANTILLA
            $sql = "INSERT INTO dha_plantillasdocumentos 
                       (id, date_entered, date_modified, modified_user_id, created_by, deleted, 
                        assigned_user_id, document_name, status_id, modulo, idioma,
                        active_date, description, category_id)
                    VALUES ('{$id}', '{$fecha_hora}', '{$fecha_hora}', '{$current_user->id}', '{$current_user->id}', 0, 
                            '{$current_user->id}', '{$NombrePlantilla}', '{$EstadoPlantilla}', '{$ModuloPlantilla}', '{$IdiomaPlantilla}', 
                            '{$fecha}', '', '') ";
            $db->query($sql);            

            // CREAMOS EL DIRECTORIO DE PLANTILLAS
            if (!is_dir($templates_dir)) {
               sugar_mkdir($templates_dir, 0775); //mkdir($templates_dir);
            }    
            
            // COPIAMOS LOS FICHEROS AL DIRECTORIO DE PLANTILLAS
            $fichero_plantilla_ejemplo = getcwd() . "/modules/DHA_PlantillasDocumentos/examples/". $filename;
            $fichero_plantilla = $templates_dir . $id . '.' . $extension;
            
            if (copy ($fichero_plantilla_ejemplo, $fichero_plantilla)){            
               // ACTUALIZAMOS LOS DATOS DEL REGISTRO CON EL FICHERO CREADO                  
               $sql = "UPDATE dha_plantillasdocumentos set filename='{$filename}', file_ext='{$extension}', file_mime_type='{$file_mime_type}', uploadfile='{$filename}' WHERE id='{$id}' ";
               $db->query($sql);
            }
         }
      }         
   
?>

      <br /><br />

      <div style="margin: 15px;">

      <span style="font-size: 1.7em;"><strong>MailMerge Reports Basic Edition has been installed!</strong></span>

      <p style="margin: 15px 0px 15px 0px; font-size: 1.7em;"><strong>How to start</strong></p>

      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      For all modules, there is new &quot;Generate Document&quot; action in ListView (need at least one record selected) and new &quot;Generate Document&quot; button in DetailView.
      </p>
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Some example templates has been installed by default for the &quot;Opportunities&quot; module. 
      Open <a href="index.php?module=DHA_PlantillasDocumentos&action=index" target="_blank">&quot;MailMerge Reports&quot;</a> to see them. 
      Then go to <a href="index.php?module=Opportunities&action=index" target="_blank">&quot;Opportunities&quot;</a> module (ListView or DetailView) to run some of the examples.
      </p> 

      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Go to &quot;MailMerge Reports&quot; module, and click on <a href="index.php?module=DHA_PlantillasDocumentos&action=varlist" target="_blank">&quot;Available variables list &amp; Generate basic template&quot;</a> menu. 
      Then select one module and select some fields to create a basic template.
      Once basic template is created, you can modify it according to your needs.
      </p> 
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Please also read the <b>readme.txt</b> file before using &quot;MailMerge Reports&quot; (in zip installation file).
      </p>   

      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      <span style='color:red'><b>Important !!</b></span> This installer have modified some SugarCRM files (see <b>readme.txt</b>).
      If you have to upgrade SugarCRM, please uninstall the component previously, checking option "Do Not Remove Tables" to preserve data and template files, and reinstall after upgrade.
      </p>            
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      <strong>Enjoy!!</strong>
      </p>         

      <p style="margin: 15px 0px 15px 0px; font-size: 1.7em;"><strong>Contact</strong></p> 
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Dharma Ingeniería<br />
      <a href="mailto:comercial@dharmasigi.com">comercial@dharmasigi.com</a><br />
      <a href="http://www.dharma.es/" target="_blank">www.dharma.es</a><br />
      </p>

      </div>
      
      <br /><br />

<?php
   }

}

?>

