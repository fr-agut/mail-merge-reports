<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function post_uninstall() {

   if ($_REQUEST['mode'] == 'Uninstall') {
      // BORRADO DE LOS FICHEROS QUE QUEDEN DEL MODULO
      $module_dir = getcwd() . "/modules/DHA_PlantillasDocumentos";
      if (is_dir($module_dir)) {
         @rmdir_recursive('modules/DHA_PlantillasDocumentos');
         
         $module_dir = getcwd() . "/custom/modules/DHA_PlantillasDocumentos";
         if (is_dir($module_dir)) {
            @rmdir_recursive('custom/modules/DHA_PlantillasDocumentos');
         }   
      }
      
      // BORRADO DE LAS IMAGENES
      $ficheros = array (
         'custom/themes/default/images/CreateDHA_PlantillasDocumentos.png',
         'custom/themes/default/images/DHA_PlantillasDocumentos.png',
         'custom/themes/default/images/DHA_PlantillasDocumentosVarList.png',
         'custom/themes/default/images/docm_image_inline.gif',
         'custom/themes/default/images/docx_image_inline.gif',
         'custom/themes/default/images/icon_address_16.png',
         'custom/themes/default/images/icon_bool_16.png',
         'custom/themes/default/images/icon_calculated_16.png',
         'custom/themes/default/images/icon_currency_16.png',
         'custom/themes/default/images/icon_date_16.png',
         'custom/themes/default/images/icon_datetime_16.png',
         'custom/themes/default/images/icon_DHA_PlantillasDocumentos.png',
         'custom/themes/default/images/icon_DHA_PlantillasDocumentos_32.png',
         'custom/themes/default/images/icon_encrypt_16.png',
         'custom/themes/default/images/icon_enum_16.png',
         'custom/themes/default/images/icon_file_16.png',
         'custom/themes/default/images/icon_float_16.png',
         'custom/themes/default/images/icon_generic_16.png',
         'custom/themes/default/images/icon_html_16.png',
         'custom/themes/default/images/icon_id_16.png',
         'custom/themes/default/images/icon_iframe_16.png',
         'custom/themes/default/images/icon_image_16.png',
         'custom/themes/default/images/icon_int_16.png',
         'custom/themes/default/images/icon_multienum_16.png',
         'custom/themes/default/images/icon_parent_type_16.png',
         'custom/themes/default/images/icon_phone_16.png',
         'custom/themes/default/images/icon_radioenum_16.png',
         'custom/themes/default/images/icon_relate_16.png',
         'custom/themes/default/images/icon_text_16.png',
         'custom/themes/default/images/icon_time_16.png',
         'custom/themes/default/images/icon_url_16.png',
         'custom/themes/default/images/icon_email_16.png',
         'custom/themes/default/images/icon_varchar_16.png',
         'custom/themes/default/images/odt_image_inline.gif',
         'custom/themes/default/images/pdf_image_inline.gif',
         'custom/themes/default/images/toggle-expand.png',
         'custom/themes/default/images/toggle-shrink.png'
      );
      foreach ($ficheros as $fichero) {
         $fichero = getcwd() . "/" . $fichero;
         @unlink ($fichero);
      }
      
      // REPAIR & REBUILD
      // require_once("modules/Administration/QuickRepairAndRebuild.php");
      // $rac = new RepairAndClear();
      // $rac->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), false, false);  
   }   
//}
  
?>
