<?php

require_once('include/MVC/Controller/SugarController.php');
  
class DHA_PlantillasDocumentosController extends SugarController {

   ///////////////////////////////////////////////////////////////////////////
   function action_editview(){
      $this->view = 'edit';
      $GLOBALS['view'] = $this->view;
      
      // Nota: para que aparezca el boton de "Quitar" en el editview (y por lo tanto funcione lo siguiente), hay que
      //       quitar la propiedad 'noChange' del vardef del campo "uploadfile" (que es de tipo file)
      if(!empty($_REQUEST['deleteAttachment'])){
         ob_clean();
         //echo $this->bean->deleteAttachment($_REQUEST['isDuplicate']) ? 'true' : 'false';
         echo $this->bean->BorraArchivoPlantilla($this->bean->id) ? 'true' : 'false';
         sugar_cleanup(true);
      }
   }
   
   ///////////////////////////////////////////////////////////////////////////
   function action_generatedocument(){
      // Ver la funcion action_massupdate en include\MVC\Controller\SugarController.php
      // Esta accion ser� llamada tanto desde el listview (como si fuera un massupdate) como desde el detailview (con un boton)
      
      // Si no se anula la vista por defecto, devuelve tambien el html de una vista (supongo que la que est� por defecto), y no es lo que se requiere aqui
      $this->view = '';
      $GLOBALS['view'] = '';      

      $bean = SugarModule::get($_REQUEST['moduloplantilladocumento'])->loadBean();
      
      if(!$bean->ACLAccess('detail')){
         ACLController::displayNoAccess(true);
         sugar_cleanup(true);
      }

      set_time_limit(0); //I'm wondering if we will set it never goes timeout here.
      // until we have more efficient way of handling MU, we have to disable the limit
      $GLOBALS['db']->setQueryLimit(0);

      require_once('modules/DHA_PlantillasDocumentos/MassGenerateDocument.php');
      $massDoc = new MassGenerateDocument();      
      $massDoc->setSugarBean($bean);
      if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == 'entire') {
         $massDoc->generateSearchWhere($_REQUEST['moduloplantilladocumento'], $_REQUEST['current_query_by_page']);
      }      
      $massDoc->handleMassGenerateDocument();
   }   
   
   ///////////////////////////////////////////////////////////////////////////
   function action_varlist(){

      // Se ha creado una vista nueva. Ver modules\DHA_PlantillasDocumentos\views\view.varlist.php
      $this->view = 'varlist';
      $GLOBALS['view'] = $this->view;      
   }

   ///////////////////////////////////////////////////////////////////////////
   function action_modulevarlist(){

      $this->view = '';
      $GLOBALS['view'] = '';

      require_once('modules/DHA_PlantillasDocumentos/Generate_Document.php');
      $GD = new Generate_Document($_REQUEST['moduloPlantilla'], NULL, NULL);  
      $GD->ObtenerHtmlListaVariables();
   }

   ///////////////////////////////////////////////////////////////////////////
   function action_crearplantillabasica(){
   
      require_once('modules/DHA_PlantillasDocumentos/Generate_Document.php');
      $GD = new Generate_Document($_REQUEST['moduloPlantilla'], NULL, NULL);
      $GD->CrearPlantillaBasica();
   }   
   
}
?>
