<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function post_install() {
   
   if ($_REQUEST['mode'] == 'Install') {
      global $sugar_config, $sugar_version, $current_language, $app_list_strings;

      // ASIGNACION DEL IDIOMA POR DEFECTO DE LAS PLANTILLAS EN BASE AL IDIOMA DEL SISTEMA
      // En el pre_install se ha asignado ya al parametro DHA_templates_default_lang el valor por defecto 'en_US' ... aqui se intenta refinar un poco mas esa asignaci�n
      
      if (isset($sugar_config['default_language']))
         $idioma_defecto = $sugar_config['default_language'];
      else 
         $idioma_defecto = $current_language;
         
      if ($idioma_defecto){
         $idioma = '';
         $idioma_defecto = strtolower($idioma_defecto);
         
         // Nota: en este punto parece que Sugar no ha cargado las extensiones del lenguaje en $app_list_strings, asi que cargamos esa variable a traves del fichero de lenguaje del componente
         //require_once("custom/Extension/application/Ext/Language/{$current_language}.MailMergeReports.php");
         require_once("custom/Extension/application/Ext/Language/en_us.MailMergeReports.php");         
         
         foreach ($app_list_strings['dha_plantillasdocumentos_idiomas_dom'] as $key => $value) {
            if (strtolower($key) == $idioma_defecto) {
               $idioma = $key;
               break;
            }
         }
         
         if (!$idioma && strpos($idioma_defecto, '_') !== false) {
            $idioma_defecto = explode('_', $idioma_defecto);
            $idioma_defecto = $idioma_defecto[0];
            
            foreach ($app_list_strings['dha_plantillasdocumentos_idiomas_dom'] as $key => $value) {
               if (strtolower($key) == $idioma_defecto) {
                  $idioma = $key;
                  break;
               }
            }         
         }
         
         if (!$idioma) {
            $idioma = 'en_US';
         }         
         
         if ($idioma) {
            require_once('modules/Configurator/Configurator.php');
            $configurator = new Configurator();

            $configurator->config['DHA_templates_default_lang'] = $idioma;
               
            $configurator->handleOverride();
            unset($configurator);         
         }
      }
      
      
      
   
      // CAMBIAMOS LOS FICHEROS ORIGINALES DE SUGAR 
      require_once("modules/DHA_PlantillasDocumentos/sugar_files/{$sugar_version}/copydefs.php");
      foreach ($copydefs as $copydef) {
         $GLOBALS['log']->debug("*********************** MailMerge Reports: OVERRIDING {$copydef['to']}");
         
         $from = getcwd() . "/modules/DHA_PlantillasDocumentos/sugar_files/{$sugar_version}/modified/" . $copydef['from'];
         $to = getcwd() . "/" . $copydef['to'];
         $OK = copy($from, $to);
         
         if ($OK)
            $GLOBALS['log']->debug("*********************** MailMerge Reports: OVERRIDED {$copydef['to']}");
         else 
            $GLOBALS['log']->debug("*********************** MailMerge Reports: Fail OVERRIDING {$copydef['to']}");   
      }
   }

//}

?>

