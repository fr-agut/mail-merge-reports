<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function pre_install() {
   // AÑADIMOS LOS PARÁMETROS DE CONFIGURACIÓN POR DEFECTO (en config_override.php)
   // En el post_install la asignación del idioma por defecto se refinará un poco mas
   
   require_once('modules/Configurator/Configurator.php');
   $configurator = new Configurator();

   if (!isset($configurator->config['DHA_templates_default_lang']))
      $configurator->config['DHA_templates_default_lang'] = 'en_US';

   if (!isset($configurator->config['DHA_templates_dir']))
      $configurator->config['DHA_templates_dir'] = 'document_templates/';

   if (!isset($configurator->config['DHA_OpenOffice_exe']))
      $configurator->config['DHA_OpenOffice_exe'] = '';
      
   if (!isset($configurator->config['DHA_OpenOffice_cde']))
      $configurator->config['DHA_OpenOffice_cde'] = '';       
      
   $configurator->handleOverride();
   unset($configurator);

//}
 
?>
