<?php
$manifest = array(
   'acceptable_sugar_versions' => array (   
      // 'regex_matches' => array (
         // 0 => "6\.2\.*",
         // 1 => "6\.3\.*",
         // 1 => "6\.4\.*",
         // 1 => "6\.5\.*",         
      // ),
      'exact_matches' => array ('6.3.0','6.3.1','6.3.2','6.3.3'),      
   ),
   'acceptable_sugar_flavors' => array (
      0 => 'CE',
   ),
   'is_uninstallable' => true,
   'remove_tables' => 'prompt',
   'key' => 'DHA',
   'name' => 'MailMerge Reports Basic',
   'description' => 'Office Open XML (.docx) and OpenDocument (.odt) Reports',
   'author' => 'Dharma Ingeniería',
   'published_date' => '2013/09/06',
   'version' => '1.1.14',
   'type' => 'module',
   'icon' => '',
);

$installdefs = array(
   'id' => 'MailMergeReports',
   'image_dir' => '<basepath>/icons',
   
   // 'mkdir' => array(
      // '/document_templates/',
   // ),   
   
   'beans' => array(
      array(
         'module'          => 'DHA_PlantillasDocumentos',
         'class'           => 'DHA_PlantillasDocumentos',
         'path'            => 'modules/DHA_PlantillasDocumentos/DHA_PlantillasDocumentos.php',
         'tab'             => true, 
      )
   ),
   
   'language' => array(
      array(
         'from'            => '<basepath>/language/en_us.MailMergeReports.php',
         'to_module'       => 'application',
         'language'        => 'en_us' 
      ),
      array(
         'from'            => '<basepath>/language/es_es.MailMergeReports.php',
         'to_module'       => 'application',
         'language'        => 'es_es' 
      ),
   ),
   
   'copy' => array(
      array(
         'from' => '<basepath>/modules/DHA_PlantillasDocumentos',
         'to'   => 'modules/DHA_PlantillasDocumentos',         
      ),    
   ),
   
   // Si el directorio "actions" se llamara "scripts" y los nombres de los ficheros son los standard, esto no sería necesario.
   // Si se hace como "scripts" el codigo de los ficheros debe de estar encapsulado en funciones (pre_install(), post_install(), etc.),
   // pero si se hace declarandolos en el manifest.php (como aqui) el código no se tiene que encapsular en funciones.
   // Otra diferencia es que si lo hacemos como "scripts", y el manifest es de un módulo, no se ejecuta el script de post_uninstall (el código no lo llama para ese caso)
   
   'pre_execute' => array(
      0 => '<basepath>/actions/pre_install.php',
   ),
   
   'post_execute' => array(
      0 => '<basepath>/actions/post_install.php',
   ),
   
   'pre_uninstall' => array(
      0 => '<basepath>/actions/pre_uninstall.php',
   ),
   
   'post_uninstall' => array(
      0 => '<basepath>/actions/post_uninstall.php',
   ),

);

/* if (!preg_match('/^6|(5\.(?>[2-9]|1\.0[a-z]))/', $GLOBALS['sugar_version']))
      $installdefs['copy'][] =
                  array('from'    => '<basepath>/modules/ModuleBuilder/views/view.modulefield.php',
                        'to'      => 'modules/ModuleBuilder/views/view.modulefield.php',
               ); */
                
?>
