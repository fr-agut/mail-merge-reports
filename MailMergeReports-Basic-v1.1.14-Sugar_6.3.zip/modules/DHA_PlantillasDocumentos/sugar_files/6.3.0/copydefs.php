<?php
   $copydefs = array (
      0 => array (
         'from' => 'download.php',
         'to' => 'download.php',
      ),
      1 => array (
         'from' => 'ListViewDisplay.php',
         'to' => 'include/ListView/ListViewDisplay.php',
      ), 
      2 => array (
         'from' => 'ListViewSmarty.php',
         'to' => 'include/ListView/ListViewSmarty.php',
      ),
      3 => array (
         'from' => 'header.tpl',
         'to' => 'include/DetailView/header.tpl',
      ),       
      4 => array (
         'from' => 'DetailView.tpl',
         'to' => 'include/DetailView/DetailView.tpl',
      ),
      5 => array (
         'from' => 'EditView2.php',
         'to' => 'include/EditView/EditView2.php',
      ),   
      6 => array (
         'from' => 'function.sugar_button.php',
         'to' => 'include/Smarty/plugins/function.sugar_button.php',
      ),       
   );
?>
